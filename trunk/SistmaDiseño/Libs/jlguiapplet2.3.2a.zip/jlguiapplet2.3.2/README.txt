jlGuiApplet 2.3.2a - Full Edition
Copyright JavaZOOM 1999-2006
http://www.javazoom.net

==========================================================
jlGuiApplet support page :
http://www.javazoom.net/applets/jlguiapplet/

Applets Forums :
http://www.javazoom.net/services/forums/index.jsp
==========================================================

--------------------
12/10/2006 : v2.3.2a
--------------------
- HTML + JavaScript samples updated to add Internet Explorer 7 support.


-------------------
07/10/2005 : v2.3.2
-------------------
- Volume value property added in jlgui.ini.
- Workaround included for custom HTTP error messages issue.
- JavaScript control panel support added for Firefox/Mozilla.
- JLayer 1.0 included.
- MP3SPI 1.9.2 included.
- VorbisSPI 1.0.1 included.


-------------------
10/04/2004 : v2.3.1
-------------------
- Bug fixed under some JRE 1.3.
- JRE 1.5 support added.


-----------------
06/01/2004 : v2.3
-----------------
- Audio formats support improved :
  + MP3 ID3v1 and v2 tags support added.
  + Shoutcast ICY meta data support (title streaming) added.
  + Ogg Vorbis comments support added.
  + WAV support added.
  + AU support added.

- Skins support improved :
  + Equalizer with Presets added.    
  + Playlist added.
    Add URL, Add File, Add Dir disabled.
  + File Info pop-up added.
  + Volume and balance bugs fixed.
  + Title marquee added.
  + "Loading" and "Buffering" messages added for stream loading.
  + TranceMaster skin embedded.

- JavaScript Control Panel improved : 
  + Security exception bug fixed with self-signed applet and JavaPlugin 1.4+.
  + Volume and Balance controls added.

- PLS support added for playlist.

- MP3 SPI 1.9.1 included.
- Vorbis SPI 1.0 included.
- jlGui2.3-light included.


-----------------
10/01/2003 : v2.2
-----------------
- JavaScript control panel sample added :
    play, stop, pause, shuffle, repeat, next, previous,
    loadplaylist, playlistdump, currentstate, currentsong,
    loadskin.
- Bug fixed for remote/local shoutcast streams playing.
- useragent parameter added to simulate audio client.
- forceOgg parameter added to force Ogg Vorbis audio format use.
- Documentation updated (see support page).

+ JavaLayer 0.3 included (jl030.jar).
+ MP3SPI 1.6 included (mp3sp.1.6.jar)
+ jlGui 2.2 included (jlGui2.2.jar, jid3.jar)

+ ShoutCast 1.9.2 support added.


-------------------
03/24/2003 : v2.1.2
-------------------
Ogg Vorbis audio format support added.
- vorbisspi0.7.jar (Vorbis SPI).
- jorbis-0.0.12.jar (Vorbis engine)
- jogg-0.0.5.jar (Vorbis engine)


-------------------
09/02/2002 : v2.1.1
-------------------
jlGui Applet is a free and open source MP3 player based on jlGui project from javazoom.net
It supports MP3 (MPEG 1/2/2.5 Layer 1/2/3), WAV, AIFF an AU audio formats. It's WinAmp 2.0 
skins and M3U playlist compliant.

jlGuiApplet package includes :
 - jl020.jar (MP3 engine)
 - mp3sp.1.5.jar (MP3 SPI)
 - jlGui2.1.1.jar (jlGui classes)
 - jlGuiApplet2.1.1.jar (Applet classes)
 - jlgui.ini (Advanced configuration file)
 - skins/wa021.wsz (WinAmp skin)
 - playerapplet.html (HTML sample code)
 - Readme.txt (This file)  
 - src/ folder (Applet sources)

Notes :
- To test jlGuiApplet inclued sample you should use a web server to avoid security exception.
- jlGuiApplet is an Applet version of jlGui - Java Music Player - open source project.
  jlGui homepage : http://www.javazoom.net/jlgui/jlgui.html
